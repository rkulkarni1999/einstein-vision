# Einsten Vision - Phase 1 

## Methodology

- The approach we are taking is that for every frame of the front camera video, we first perform instance  segmentation of the desired classes, then compute centroid of the bounding boxes. Later depth is computed of these centroids and then stored in a json file. Later the json file is called in the blender scripting tab where the 2D image coordinates of the centroid are projected into the 3D Blender space by rearranging the 2D-3D perspective projection equation.   

## Instance Segmentation Using Detic.  

[Repository for Detic](https://github.com/facebookresearch/Detic)

### Segmentation Mask 

![Segmentation Mask](segmentation_masks_using_detic/segmentation_images_seq4/4.jpg)

### Binary Mask

![Binary Mask](segmentation_masks_using_detic/segmentation_images_seq4/4.jpg)

## Lane Detection Using CLRNet. 

[Repository for CLRNet](https://github.com/Turoad/CLRNet)

## Predicting One Shot Metic Depth using ZoeDepth

[Repository for ZoeDepth](https://github.com/isl-org/ZoeDepth)

### Depth Map inference 

![Depth Map](depth_maps_using_zoedepth/depth_map_seq4/depth_map_4.jpg)

### Centroid Depth Estimate

![Centroid Depth Estimate](centroid_depth_overlay_using_zoe_depth/centroid_depth_seq4/4.jpg_overlay_with_depth.jpg)

## Final Output Comparison

### Original

![Original](original_and_rendered_images/sequence4/4_original.jpg)

### Rendered Output

![Rendered](original_and_rendered_images/sequence4/sequence4img4_rendered.jpg)

## Limitation of this approach. 

- The lanes have not yet been categorized into dotted, red, and white lanes. Will have to explore different network for that. 
- When a object is half detected using detic, because we are considering only the 2D bounding box, the centroid sometimes shifts upwards which results in the object being spawned at the wrong height. This will be fixed once we obtain 3D bounding boxes that will give a better centroid estimate. 
- Currently the objects that are being spawned do not consider their orientation with respect to the camera. Therefore, all vehicles and objects are facing forwards or backwards irrespective of their original orientation. This will be fixed when we start compute 3D bounding boxes for our detected objects.    

